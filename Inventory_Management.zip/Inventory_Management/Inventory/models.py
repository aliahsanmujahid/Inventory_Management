from django.db import models

class Device(models.Model):
    type = models.CharField(max_length=100,blank=False)
    price = models.IntegerField()
    choices = (
        ('AVILABEL','Item Ready To Be Purched'),
        ('SOLD','Item Sold'),
        ('RESTOCKINGS','Item Restoring in few Days')
    )
    status = models.CharField(max_length=100,choices=choices,default="SOLD")
    issues = models.CharField(max_length=100,default="No issues")
    
    class Meta:
        abstract = True
        
    def __str__(self):
        return 'Type : {0} Price : {1}'.format(self.type,self.price)


class Labtop(Device):
    class Meta:
        verbose_name = "Labtop"
class Desktop(Device):
     class Meta:
        verbose_name = "Desktop"
class Mobile(Device):
     class Meta:
        verbose_name = "Mobile"