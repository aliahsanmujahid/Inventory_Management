from django.contrib import admin
from .models import Labtop,Desktop,Mobile
# Register your models here.


admin.site.register(Labtop)
admin.site.register(Desktop)
admin.site.register(Mobile)
