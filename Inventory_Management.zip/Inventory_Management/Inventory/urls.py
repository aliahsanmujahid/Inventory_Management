from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^$',views.index,name='index'),
    
    url(r'^display/labtop$',views.display_Labtop,name='display_Labtop'),
    url(r'^display/desktop$',views.display_Desktop,name='display_Desktop'),
    url(r'^displa/mobile$',views.display_Mobile,name='display_Mobile'),
    
    url(r'^add_laptop$',views.add_laptop,name='add_laptop'),
    url(r'^add_desktop$',views.add_desktop,name='add_desktop'),
    url(r'^add_mobile$',views.add_mobile,name='add_mobile'),

    url(r'^edit_laptop/(?P<pk>\d+)$',views.edit_laptop,name='edit_laptop'),
    url(r'^edit_desktop/(?P<pk>\d+)$',views.edit_desktop,name='edit_desktop'),
    url(r'^edit_mobile/(?P<pk>\d+)$',views.edit_mobile,name='edit_mobile'),

    url(r'^delete_laptop/(?P<pk>\d+)$',views.delete_labtop,name='delete_labtop'),
    url(r'^delete_desktop/(?P<pk>\d+)$',views.delete_desktop,name='delete_desktop'),
    url(r'^delete_mobile/(?P<pk>\d+)$',views.delete_mobile,name='delete_mobile'),
    url(r'^/search/$', views.search, name='search'),
]