from django.shortcuts import render,redirect,get_object_or_404
from .models import *
from .forms import *
# Create your views here.


def index(request):
    
    items = Labtop.objects.all()
    
    context = {
        'items' : items,
        'header': Labtop._meta.verbose_name
    }
    return render(request,'index.html',context)



def display_item(request,model):

    items = model.objects.all()
    
    context = {
        'items' : items,
        'header': model._meta.verbose_name
    }
    return render(request,'index.html',context)


def display_Labtop(request):
    return display_item(request,Labtop)
def display_Desktop(request):
    return display_item(request,Desktop) 
def display_Mobile(request):
    return display_item(request,Mobile)
    





def add_device(request,cls,model):
    items = model.objects.all()
    if request.method == 'POST':
        form = cls(request.POST)
        if form.is_valid():
            form.save()
            context = {
               'items' : items,
               'header': model._meta.verbose_name
            }
            return render(request,'index.html',context)
    else:
        form = cls()
        return render(request,'add_new.html',{'form':form})  

def add_laptop(request):
    return add_device(request,LaptopForm,Labtop)
 
def add_desktop(request):
    return add_device(request,DesktopForm,Desktop)

def add_mobile(request):
    return add_device(request,MobileForm,Mobile)




def edit_device(request,pk,model,cls):
    item = get_object_or_404(model,pk=pk)
    items = model.objects.all()
    if request.method == 'POST':
        form = cls(request.POST,instance=item)
        if form.is_valid():
            form.save()
            context = {
               'items' : items,
               'header': model._meta.verbose_name
            }
            return render(request,'index.html',context)
    else:
        form = cls(instance=item)
        return render(request,'add_new.html',{'form':form})  


def edit_laptop(request,pk):
    return edit_device(request,pk,Labtop,MobileForm)

def edit_desktop(request,pk):
    return edit_device(request,pk,Desktop,MobileForm)

def edit_mobile(request,pk):
    return edit_device(request,pk,Mobile,MobileForm)





def delete_item(request,pk,model):
    model.objects.filter(id=pk).delete()
    items = model.objects.all()
    context = {
            'items' : items,
            'header': model._meta.verbose_name
        }
    return render(request,'index.html',context)

def delete_labtop(request,pk):
    return delete_item(request,pk,Labtop)
    
def delete_desktop(request,pk):
    return delete_item(request,pk,Desktop)

def delete_mobile(request,pk):
    return delete_item(request,pk,Mobile)



def search(request):
    if request.method == 'POST':
        value = request.POST.get('value')
        device = request.POST.get('device')
    
    if device == 'Labtop':
        items = Labtop.objects.filter(type=value)
        header = Labtop._meta.verbose_name
        lenitems = len(items)
    elif device == 'Desktop':
        items = Desktop.objects.filter(type=value)
        header = Desktop._meta.verbose_name
        lenitems = len(items)
    else:
        items = Mobile.objects.filter(type=value)
        header = Mobile._meta.verbose_name
        lenitems = len(items)
    
    
    if device == 'all':
        items1 = Labtop.objects.filter(type=value)
        items2 = Desktop.objects.filter(type=value)
        items3 = Mobile.objects.filter(type=value)
        context = {
        'items1' : items1,
        'items2' : items2,
        'items3' : items3,
        'lenitems1' : len(items1),
        'lenitems2' : len(items2),
        'lenitems3' : len(items3),
        }
        return render(request,'index2.html',context)



    context = {
        'items' : items,
        'header': header,
        'lenitems': lenitems
    }
    return render(request,'index.html',context)

